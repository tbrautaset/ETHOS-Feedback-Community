-- ImmersionRC Ghost Module

local function init()
    system.registerGhostModule()
end

return {init=init}
